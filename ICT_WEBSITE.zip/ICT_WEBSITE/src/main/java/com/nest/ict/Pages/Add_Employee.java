package com.nest.ict.Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.nest.ict.Utility.PageUtility;

public class Add_Employee {
	WebDriver driver;
	@FindBy(xpath="//input[@id='ContentPlaceHolder1_txtName']")
	private WebElement NAME;
	@FindBy(xpath="//input[@id='ContentPlaceHolder1_txtPassword']")
	private WebElement PASSWORD;
	@FindBy(xpath="//input[@id='ContentPlaceHolder1_txtEmail']")
	private WebElement EMAIL;
	@FindBy(xpath="//select[@id='ContentPlaceHolder1_drpDesignation']")
	private WebElement Designation;
	@FindBy(xpath="//select[@id='ContentPlaceHolder1_drpReportingTo']")
	private WebElement REPORT;	
	@FindBy(xpath="//select[@id='ContentPlaceHolder1_drpGroup']")
	private WebElement MEMBER;
	@FindBy(xpath="//input[@id='ContentPlaceHolder1_txtEmployeeId']")
	private WebElement EMPID;
	@FindBy(xpath="//input[@id='ContentPlaceHolder1_txtConfirmPassword']")
	private WebElement CONFIRMPSWD;
	@FindBy(xpath="//input[@id='ContentPlaceHolder1_txtMobileNumber']")
	private WebElement MOBILE ;
	@FindBy(xpath="//select[@id='ContentPlaceHolder1_drpEmployeeType']")
	private WebElement EMPTYPE;
	@FindBy(xpath="//input[@id='ContentPlaceHolder1_ChkReportingStaff']")
	private WebElement REPORTSTAFF;
	@FindBy(xpath="//textarea[@id='ContentPlaceHolder1_txtAddress']")
	private WebElement ADDRESS;
	@FindBy(xpath="//input[@id='ContentPlaceHolder1_btnSubmit']")
	private WebElement SUBMIT;
	
public Add_Employee(WebDriver driver) {
        this.driver=driver;
        PageFactory.initElements(driver, this);
    }
public void setName(String struserName) {
    
	 PageUtility.sendInput(NAME, struserName);

}

public void setPassword(String strPassword) {


   PageUtility.sendInput(PASSWORD, strPassword);

}

public void setMail(String streMail) {


   PageUtility.sendInput(EMAIL, streMail);

}

public void setDesignation(String strDesignation) {


   PageUtility.sendInput(Designation, strDesignation);

}

public void setreportingTo(String strreportingTo) {


   PageUtility.sendInput(REPORT, strreportingTo);

}

public void setmemberOf(String strmemberOf) {


   PageUtility.sendInput(MEMBER, strmemberOf);

}

public void setempId(String strempId) {


   PageUtility.sendInput(EMPID, strempId);

}

public void setPassword2(String strPassword2) {


   PageUtility.sendInput(CONFIRMPSWD, strPassword2);

}

public void setNumber(String strNumber) {


   PageUtility.sendInput(MOBILE, strNumber);

}

public void setempType(String strempType) {


   PageUtility.sendInput(EMPTYPE, strempType);

}

public void clickreportingStaff() {
   
	PageUtility.selectChkBox(REPORTSTAFF);
       
}

public void setAddress(String straddress) {
   
	 PageUtility.sendInput(ADDRESS, straddress);

}

       
public void clickLogin() {
           
	PageUtility.clickBtn(SUBMIT, driver);
       
}

}
