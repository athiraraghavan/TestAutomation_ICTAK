package com.nest.ict.Constants;

public class AutomationConstant {
	
	public static String username="practice.swtesting@gmail.com";
	public static String password="123";
	public static String expname="ATHIRA";

}
