package com.nest.ict.Utility;

import java.sql.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class PageUtility {

	public static void sendInput(WebElement element,String input) {
		
		element.sendKeys(input);
	}
	public static void clickBtn(WebElement element,WebDriver driver)
	{
	
		element.click();
	}
	public static void scrollTillElement(WebDriver driver,WebElement element)
	{
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true):",element);
		
	}
	public static String readText(WebElement element) {
		
		return element.getText();
	}
	public static boolean display(WebElement ele) {
		
		return ele.isDisplayed();
	}
	   public static void selectChkBox(WebElement ele) {
			
			if(!ele.isSelected())
			{
				ele.click();
			}
			
		}
	public static void moveElement(WebDriver driver,WebElement ele) {
		Actions action=new Actions(driver);
		action.moveToElement(ele).click().build().perform();
	}
	public static void doubleClick(WebDriver driver) {
		Actions action=new Actions(driver);
		action.doubleClick().build().perform();
	}
	public static void contextClick(WebDriver driver) {
		Actions action=new Actions(driver);
		action.contextClick().build().perform();
	}
	 public static void hoverEg(WebDriver driver,WebElement element) {
			
			Actions action=new Actions(driver);
			action.moveToElement(element).build().perform();
		}
	    
	    
	public static void enterEvent(WebDriver driver) {
		Actions action=new Actions(driver);
		action.sendKeys(Keys.ENTER);
		
	}
	public static void controlEvent(WebDriver driver) {
		Actions action=new Actions(driver);
		action.keyDown(Keys.ENTER).sendKeys("z").keyUp(Keys.CONTROL).perform();;
		
	}
	public static  void dateEvent(WebDriver driver, WebElement ele) {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");  
		   LocalDateTime now = LocalDateTime.now();  
		 ele.sendKeys(dtf.format(now));
	}
	 public static void enterKeyEg(WebDriver driver)
	    {
	    	
	    	Actions action=new Actions(driver);
	    	action.sendKeys(Keys.ARROW_DOWN);
	    	action.sendKeys(Keys.ENTER);
	    }
	    
//	public static List<WebElement> dropDown(WebDriver driver,WebElement ele) {
//		Select dropdown = new Select(ele);
//		List<WebElement> options =dropdown.getOptions();
//	    return options;
//				
//	}
	public static void select(WebElement ele,String status) {
		Select s=new Select(ele);
		s.selectByVisibleText(status);
	}
	 public static void alertEg(WebDriver driver)
	    {
	    	Alert alert=driver.switchTo().alert();
	    	alert.accept();
	    }

}
