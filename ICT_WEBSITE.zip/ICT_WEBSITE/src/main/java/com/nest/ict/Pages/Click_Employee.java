package com.nest.ict.Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.nest.ict.Utility.PageUtility;

public class Click_Employee {
	WebDriver driver;
	@FindBy(linkText="Employee")
    private WebElement clickEmployee;
	
	@FindBy(linkText="Add Employee")
    private WebElement clickAddEmployee;
	
	
	public Click_Employee(WebDriver driver) {
        this.driver=driver;
        PageFactory.initElements(driver, this);
    }
	public void ClickEmp() {
		PageUtility.hoverEg(driver, clickEmployee);
			}
	public void ClickAddEmp() {
		PageUtility.clickBtn(clickAddEmployee, driver);
	}
	

}
