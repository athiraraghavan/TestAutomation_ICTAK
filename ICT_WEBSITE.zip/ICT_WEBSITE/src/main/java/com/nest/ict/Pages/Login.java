package com.nest.ict.Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.nest.ict.Constants.AutomationConstant;
import com.nest.ict.Utility.PageUtility;

public class Login {
	WebDriver driver;
	@FindBy(id="txtUsername")
	private WebElement Username;
	@FindBy(id="txtPassword")
	private WebElement Password;
	@FindBy(name="btnSubmit")
	private WebElement Button;
	
public Login(WebDriver driver) {
        this.driver=driver;
        PageFactory.initElements(driver, this);
    }
public void EnterUserName() {
	PageUtility.sendInput(Username,AutomationConstant.username);
}
public void Enterpswd() {
	PageUtility.sendInput(Password,AutomationConstant.password);
}
public void LoginButton() {
	PageUtility.clickBtn(Button, driver);
	
}

}
