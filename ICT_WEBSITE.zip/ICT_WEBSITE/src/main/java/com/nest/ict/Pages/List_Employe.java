package com.nest.ict.Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.nest.ict.Utility.PageUtility;

public class List_Employe {
	
	WebDriver driver;
	
	@FindBy(linkText="Employee")
	private WebElement empLink;
	
	@FindBy(linkText="List Employee")
	private WebElement listLink;
	
	@FindBy(linkText="Edit")
	private WebElement editbtn; 
	
	@FindBy(id="ContentPlaceHolder1_gvList_LinkButton2_0")
	private WebElement deletebtn; 
	
	public List_Employe(WebDriver driver) {
    	this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	public void openEmployeeList()
	{
		
		PageUtility.hoverEg(driver,empLink);
		PageUtility.clickBtn(listLink, driver);
	}
	
//	public void clickEditbtn()
//	{
//		
//		PageUtility.enterEvent(driver);
//		PageUtility.clickBtn(editbtn, driver);
//		
//	}
//	
//	
//	public void clickDeletebtn()
//	{
//		
//		PageUtility.enterEvent(driver);
//		PageUtility.clickBtn(deletebtn, driver);
//		PageUtility.alertEg(driver);
//	}
	

}
