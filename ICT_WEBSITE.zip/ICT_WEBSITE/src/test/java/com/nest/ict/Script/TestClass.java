package com.nest.ict.Script;

import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import static org.testng.AssertJUnit.assertEquals;
import org.testng.annotations.Test;

import com.nest.ict.Base.BaseClass;
import com.nest.ict.Constants.AutomationConstant;
import com.nest.ict.Pages.Add_Employee;
import com.nest.ict.Pages.Click_Employee;
import com.nest.ict.Pages.List_Employe;
import com.nest.ict.Pages.Login;

import dev.failsafe.internal.util.Assert;

public class TestClass extends BaseClass {
	Login log;
	Click_Employee emp;
	Add_Employee add;
	List_Employe ep;
  @Test(priority=1)
  public void SignUp() {
	  log=new Login(getDriver());
	  log.EnterUserName();
	  log.Enterpswd();
	  log.LoginButton();
  }
  @Test(priority=2)
  public void Employee_Click() {
	  emp=new Click_Employee(getDriver());
	  emp.ClickEmp();
	  emp.ClickAddEmp();
	 
  }
  @Test(priority=3)
  public void Add_Employee() {
	  add=new Add_Employee(getDriver());
	  add.setName("Athira T");
	  add.setPassword("Athi#34");
	  add.setMail("aathira712@gmail.com");
	  add.setDesignation("HR");
	  add.setreportingTo("T4_HR");
	  add.setmemberOf("Manager");
	  add.setempId("51379");
	  add.setPassword2("Athi#34");
	  add.setNumber("9188148601");
	  add.setempType("Permanant");
      add.clickreportingStaff();
	  add.setAddress("Kasaragod");
	  add.clickLogin();
  }
  @Test(priority=4)
  public void List_emp() {
	  ep=new List_Employe(getDriver());
	  ep.openEmployeeList();
//	  ep.clickEditbtn();
//	  ep.clickDeletebtn();
	 
  }
 
}
